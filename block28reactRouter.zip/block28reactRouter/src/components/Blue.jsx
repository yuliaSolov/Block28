import React from "react";

function Blue() {
  return (
    <div className="blue">
      <h1>Blue</h1>
    </div>
  );
}

export default Blue;
