import React from "react";

const Red = () => {
  return (
    <div className="red">
      <h1>Red</h1>
    </div>
  );
};

export default Red;
